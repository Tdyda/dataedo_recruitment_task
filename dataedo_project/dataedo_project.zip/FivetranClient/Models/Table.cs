﻿namespace FivetranClient.Models;

public class Table
{
    public string NameInDestination { get; set; }
}