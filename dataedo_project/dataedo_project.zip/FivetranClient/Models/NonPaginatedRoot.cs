﻿namespace FivetranClient.Models;

public class NonPaginatedRoot<T>
{
    public T? Data { get; set; }
}