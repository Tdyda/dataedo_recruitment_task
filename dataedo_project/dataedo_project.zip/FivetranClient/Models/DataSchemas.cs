﻿namespace FivetranClient.Models;

public class DataSchemas
{
    public Dictionary<string, Schema?> Schemas { get; set; }
}